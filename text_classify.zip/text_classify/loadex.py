import pandas as pd
#from pandas import read_csv
df = pd.read_csv('pdata.csv')
print(len(df))
#print(df['label'])
srs = pd.Series(list(df['label']))
data = pd.get_dummies(srs)
all_onehots = []
for item in data.iterrows():
    onehot = [x for x in item[-1]]
    all_onehots.append(onehot)
    #for value in item: #tuple in format: (int, pandas.series)
    #    print(value)        
            
#print(pd.get_dummies(srs).head())

print(len(all_onehots))
df['onehots'] = all_onehots
print(df.tail())

df.to_csv('pdata_onehot.csv', index=False)
